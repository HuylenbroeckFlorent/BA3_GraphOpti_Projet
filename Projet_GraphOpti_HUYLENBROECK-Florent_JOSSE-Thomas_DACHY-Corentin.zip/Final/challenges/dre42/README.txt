On a trouvé 884 pour dre42.dat lors du challenge en classe.
Cependant, pendant le débrief, en ayant juste changé le nombre de fourmi, nous avons trouvé plusieurs fois l'optimal en moins de 3 minutes. Je vous ai donc inclu les screenshots de ces executions là aussi. 
